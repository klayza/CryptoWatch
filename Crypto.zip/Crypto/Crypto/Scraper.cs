﻿using HtmlAgilityPack;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace Crypto
{
    public class Scraper
    {
        private ObservableCollection<EntryModel> _entries = new ObservableCollection<EntryModel>();
            
        private ObservableCollection<EntryModel> Entries    // Original is public, not private
        {
            get { return _entries; }
            set { _entries = value; }
        }
        public Dictionary<string, string> ScrapeData(string page)
        {
            // Loads the webpage to the local machine
            Dictionary<string, string> Collections = new Dictionary<string, string>();
            var web = new HtmlWeb();
            var document = web.Load(page);

            // Gets all of the nodes with the class
            var Stocks = document.DocumentNode.SelectNodes("//*[@class = '_2mHoLKk1EmQ90Hj2VxwVKC _2cEwIPLxNCKyZSBxk7MyUQ Q0Cxwokka8qzW-qAyjdq6 pointer']");

            // Loops through each node and saves the name
            foreach (var stock in Stocks)
            {
                // The dot selects 
                var name = HttpUtility.HtmlDecode(stock.SelectSingleNode(".//div[@ class = 'text-left truncate _1hazOxgsUXq0rb-UgDZwNp _1GdBC6rgsSADLryaaGeEuX w8u1-Ks6zzfWwPQ23ywUj _36FIyjphKz71izCg1N-Uks']").InnerText);
                var price = HttpUtility.HtmlDecode(stock.SelectSingleNode(".//div[@ class = 'text-right _1hazOxgsUXq0rb-UgDZwNp LNc8C7U5Q_4hVq8G7HQHa _36FIyjphKz71izCg1N-Uks overflow-visible']").InnerText);
                if (name.ToUpper() == "BITCOIN" || name.ToUpper() == "ETHEREUM" || name.ToUpper() == "SOLANA" || name.ToUpper() == "LITECOIN" || name.ToUpper() == "CHAINLINK")
                {
                    Console.WriteLine(name + " $" + price);
                    Collections.Add(name, price);
                }
            }
            return Collections;
        }

    }
}
